package com.nuvio.tv.livetv.data

import com.nuvio.tv.core.network.NetworkResult
import com.nuvio.tv.core.poster.CustomPosterScreen
import com.nuvio.tv.domain.model.Addon
import com.nuvio.tv.domain.model.CatalogDescriptor
import com.nuvio.tv.domain.model.MetaPreview
import com.nuvio.tv.domain.model.enabledAddons
import com.nuvio.tv.domain.model.supportsExtra
import com.nuvio.tv.domain.repository.AddonRepository
import com.nuvio.tv.domain.repository.CatalogRepository
import com.nuvio.tv.livetv.model.EpgProgram
import com.nuvio.tv.livetv.model.LiveChannel
import com.nuvio.tv.livetv.ui.LiveTvSearchBridge
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Finds the poster Nuvio would show for a program, by searching the user's own addon catalogs
 * (the same catalogs Nuvio's search uses) for the program title. Uses the Home poster settings,
 * so custom posters match what the home screen shows. Only an exact or very close title match is
 * used; a wrong poster is worse than none.
 */
@Singleton
class LiveTvPosterResolver @Inject constructor(
    private val addonRepository: AddonRepository,
    private val catalogRepository: CatalogRepository
) {
    private val cache = ConcurrentHashMap<String, Result>()
    private val mutex = Mutex()

    data class Result(val poster: String?)

    /** Whether a program is a movie or a series, and how sure we are. */
    enum class Kind { MOVIE, SERIES }
    data class TypeHint(val kind: Kind, val strong: Boolean)

    /** What the guide says about the program, used to tell same-named titles apart. */
    data class Clues(
        val year: Int? = null,
        val people: List<String> = emptyList(),
        val description: String? = null
    )

    suspend fun posterFor(programTitle: String, hint: TypeHint? = null, clues: Clues = Clues()): String? {
        val query = LiveTvSearchBridge.cleanTitle(programTitle).ifBlank { programTitle.trim() }
        if (query.length < 2) return null
        val key = normalize(query) + "|" + (hint?.kind ?: "any") + "|" + (clues.year ?: "") +
            "|" + (clues.description?.hashCode() ?: 0)
        cache[key]?.let { return it.poster }
        return mutex.withLock {
            cache[key]?.let { return@withLock it.poster }
            // First the whole title. If nothing matches and the guide glued the show and episode
            // together ("The Game - The Trey Wiggs Taps Back Episode"), try the show name alone.
            var poster = runCatching { lookup(query, hint, clues) }.getOrNull()
            if (poster == null) {
                for (show in showNameCandidates(programTitle, hint)) {
                    if (normalize(show) == normalize(query)) continue
                    // The guide's year belongs to the episode, not the show, so leave it out here.
                    poster = runCatching {
                        lookup(show, hint?.copy(strong = false), clues.copy(year = null))
                    }.getOrNull()
                    if (poster != null) break
                }
            }
            cache[key] = Result(poster)
            poster
        }
    }

    private suspend fun lookup(query: String, hint: TypeHint?, clues: Clues): String? {
        val addons = withTimeoutOrNull(5_000) { addonRepository.getInstalledAddons().first() }
            ?.enabledAddons() ?: return null
        val all = searchTargets(addons)
        if (hint == null) return lookupIn(query, all.take(MAX_CATALOGS), clues)
        val preferredType = if (hint.kind == Kind.MOVIE) "movie" else "series"
        // Search the right kind of catalog first. With a strong hint (episode number, or the guide
        // says "Movie"), never take the other kind: that's how a sitcom ends up with a movie poster.
        val preferred = all.filter { it.second.apiType == preferredType }.take(MAX_CATALOGS)
        lookupIn(query, preferred, clues)?.let { return it }
        if (hint.strong) return null
        val others = all.filter { it.second.apiType != preferredType }.take(MAX_CATALOGS)
        return lookupIn(query, others, clues)
    }

    /**
     * Collects every result with the right title, then picks the best one: same release year
     * wins (Total Recall 1990 vs 2012), then shared cast/directors, then how much the
     * descriptions have in common. If the guide gives a year and no result is within a year of
     * it, nothing is shown rather than a poster for the wrong film.
     */
    private suspend fun lookupIn(
        query: String,
        targets: List<Pair<Addon, CatalogDescriptor>>,
        clues: Clues
    ): String? {
        val wanted = normalize(query)
        val exact = LinkedHashMap<String, MetaPreview>()
        var closeMatch: MetaPreview? = null

        for ((addon, catalog) in targets) {
            val result = withTimeoutOrNull(8_000) {
                catalogRepository.getCatalog(
                    addonBaseUrl = addon.baseUrl,
                    addonId = addon.id,
                    addonName = addon.displayName,
                    catalogId = catalog.id,
                    catalogName = catalog.name,
                    type = catalog.apiType,
                    extraArgs = mapOf("search" to query),
                    posterScreen = CustomPosterScreen.HOME
                ).first { it !is NetworkResult.Loading }
            }
            val items = (result as? NetworkResult.Success)?.data?.items.orEmpty()
            items.filter { normalize(it.name) == wanted && !it.poster.isNullOrBlank() }
                .forEach { exact.putIfAbsent(it.imdbId ?: it.id, it) }
            // With no year to check, the first exact match is as good as it gets.
            if (clues.year == null && clues.people.isEmpty() && clues.description.isNullOrBlank() && exact.isNotEmpty()) break
            // A result from the right year settles it.
            if (clues.year != null && exact.values.any { yearOf(it) == clues.year }) break
            if (closeMatch == null) {
                closeMatch = items.take(5).firstOrNull { item ->
                    val n = normalize(item.name)
                    !item.poster.isNullOrBlank() && n.isNotEmpty() &&
                        (n.startsWith(wanted) || wanted.startsWith(n)) &&
                        minOf(n.length, wanted.length) * 10 >= maxOf(n.length, wanted.length) * 7
                }
            }
        }

        if (exact.isNotEmpty()) {
            val best = exact.values.maxByOrNull { score(it, clues) }!!
            if (clues.year != null) {
                val y = yearOf(best)
                if (y != null && kotlin.math.abs(y - clues.year) > 1) return null
            }
            return best.poster
        }
        val close = closeMatch ?: return null
        if (clues.year != null) {
            val y = yearOf(close)
            if (y != null && kotlin.math.abs(y - clues.year) > 1) return null
        }
        return close.poster
    }

    private fun score(item: MetaPreview, clues: Clues): Double {
        var score = 0.0
        val y = yearOf(item)
        if (clues.year != null && y != null) {
            val diff = kotlin.math.abs(y - clues.year)
            score += when (diff) { 0 -> 100.0; 1 -> 80.0; else -> -100.0 }
        }
        if (clues.people.isNotEmpty()) {
            val names = clues.people.map { it.lowercase() }
            val hay = (item.director + item.writer).joinToString(" ").lowercase() + " " + item.description.orEmpty().lowercase()
            score += 30.0 * names.count { n -> n.substringAfterLast(' ').length > 2 && hay.contains(n.substringAfterLast(' ')) }
        }
        val a = words(clues.description)
        val b = words(item.description)
        if (a.isNotEmpty() && b.isNotEmpty()) {
            score += 60.0 * a.intersect(b).size / minOf(a.size, b.size)
        }
        return score
    }

    private fun yearOf(item: MetaPreview): Int? =
        Regex("""(19|20)\d{2}""").find(item.releaseInfo ?: item.released ?: "")?.value?.toIntOrNull()

    private val stopWords = setOf(
        "the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "with", "his", "her", "their", "is",
        "are", "was", "who", "that", "this", "from", "by", "as", "at", "into", "after", "when", "while"
    )

    private fun words(text: String?): Set<String> =
        text.orEmpty().lowercase().split(Regex("""[^a-z0-9]+"""))
            .filter { it.length > 3 && it !in stopWords }
            .toSet()

    /** Movie and series catalogs that need nothing but a search term, movies first. */
    private fun searchTargets(addons: List<Addon>): List<Pair<Addon, CatalogDescriptor>> =
        addons.flatMap { addon ->
            addon.catalogs
                .filter { c ->
                    c.supportsExtra("search") &&
                        c.extra.none { it.isRequired && !it.name.equals("search", ignoreCase = true) } &&
                        (c.apiType == "movie" || c.apiType == "series")
                }
                .map { addon to it }
        }

    private fun normalize(s: String): String =
        s.lowercase().replace("&", "and").filter { it.isLetterOrDigit() }

    companion object {
        private const val MAX_CATALOGS = 6

        /** " - ", " – ", " — " or " | " between a show name and an episode title. */
        private val SHOW_EPISODE_SEPARATOR = Regex("""\s+[-–—|]\s+""")

        /**
         * Possible show names hidden in a combined title, best first. "Show - Episode" always
         * counts; "Show: Episode" only for series, because plenty of films use a colon
         * ("Star Wars: A New Hope").
         */
        fun showNameCandidates(title: String, hint: TypeHint?): List<String> {
            val cleaned = LiveTvSearchBridge.cleanTitle(title).ifBlank { title.trim() }
            val out = LinkedHashSet<String>()
            SHOW_EPISODE_SEPARATOR.split(cleaned).firstOrNull()?.trim()?.let { if (it.length >= 2 && it != cleaned) out += it }
            if (hint?.kind == Kind.SERIES && cleaned.contains(": ")) {
                cleaned.substringBefore(": ").trim().let { if (it.length >= 2) out += it }
            }
            return out.toList()
        }

        /**
         * What to search for in Nuvio ("Find & stream"): for a series with a combined
         * "Show - Episode" title, just the show name, so search finds the show.
         */
        fun searchTitleFor(program: EpgProgram, channel: LiveChannel?): String {
            val hint = typeHint(program, channel)
            if (hint?.kind == Kind.SERIES) showNameCandidates(program.title, hint).firstOrNull()?.let { return it }
            return program.title
        }
        private val movieWords = Regex("""\b(movie|movies|film|films|cinema|feature)\b""", RegexOption.IGNORE_CASE)
        private val seriesWords = Regex(
            """\b(series|sitcom|episode|episodes|soap|soap opera|talk show|reality|news|game show|drama series|comedy series)\b""",
            RegexOption.IGNORE_CASE
        )

        /**
         * Works out movie vs series from the guide: an episode number or the guide's category is a
         * strong signal; failing that, the running time (under about an hour is almost always a
         * series episode, over 80 minutes usually a movie) and the channel's group are weak ones.
         */
        fun typeHint(program: EpgProgram?, channel: LiveChannel?): TypeHint? {
            if (program == null) return null
            if (!program.episode.isNullOrBlank()) return TypeHint(Kind.SERIES, strong = true)
            program.category?.let { cat ->
                if (movieWords.containsMatchIn(cat)) return TypeHint(Kind.MOVIE, strong = true)
                if (seriesWords.containsMatchIn(cat)) return TypeHint(Kind.SERIES, strong = true)
            }
            val minutes = (program.stopMs - program.startMs) / 60_000
            channel?.group?.let { g ->
                if (movieWords.containsMatchIn(g) && minutes >= 75) return TypeHint(Kind.MOVIE, strong = false)
            }
            return when {
                minutes in 1..65 -> TypeHint(Kind.SERIES, strong = false)
                minutes >= 80 -> TypeHint(Kind.MOVIE, strong = false)
                else -> null
            }
        }
    }
}
